<?php require_once('/home/users/web/b2275/d5.remaxove/etc/conn_4pr.php'); ?>
<?php include("assets/meta.shtml"); ?>
<title>Performance Realty</title>
<?php include("assets/header.shtml"); ?>
  <!-- TOP MENU -->
  <div id="menuTop">
    <?php include("assets/menu.shtml"); ?>
  </div>
  <div id="content">
    <div id="mainContent3">
      <div class="container">
        <!-- DO NOT EDIT ABOVE HERE -->
        <!-- START CONTENT -->
        <h2>Contact Us</h2>
        
        <!-- END CONTENT -->
        <!-- DO NOT EDIT BELOW HERE -->
        <p>2511 E. Market St., Suite A<br />
          Harrisonburg, VA 22801<br />
  <br />
        (540) 433-7369<br />
        (800)296-7369</p>
        <p><a href="mailto:remaxperformance@comcast.net">remaxperformance@comcast.net</a></p>
      </div>
    </div>
  </div>
  <?php include ("assets/footer.shtml"); ?>
