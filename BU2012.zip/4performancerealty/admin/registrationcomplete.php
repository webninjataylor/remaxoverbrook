<?php include("../assets/meta.shtml"); ?>
<title>Performance Realty</title>
<?php include("../assets/header.shtml"); ?>
  <div id="content" style="padding-top:0px;">
    <div id="mainContent3">
      <div class="container">
        <!-- DO NOT EDIT ABOVE HERE -->
        <!-- START CONTENT -->
        <h2>Registration Complete</h2>
        <p>Your registration request has been submitted.  You will be notified by email when your request is completed.</p>
        <!-- END CONTENT -->
        <!-- DO NOT EDIT BELOW HERE -->
      </div>
    </div>
    <?php include ("../assets/footer.shtml"); ?>
