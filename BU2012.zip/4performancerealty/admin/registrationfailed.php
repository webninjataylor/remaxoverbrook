<?php include("../assets/meta.shtml"); ?>
<title>Performance Realty</title>
<?php include("../assets/header.shtml"); ?>
  <div id="content" style="padding-top:0px;">
    <div id="mainContent3">
      <div class="container">
        <!-- DO NOT EDIT ABOVE HERE -->
        <!-- START CONTENT -->
        <h2>Registration Failed</h2>
        <p>Your registration request contained errors.  <a href="register.php">Please try again</a>.</p>
        <!-- END CONTENT -->
        <!-- DO NOT EDIT BELOW HERE -->
      </div>
    </div>
    <?php include ("../assets/footer.shtml"); ?>
