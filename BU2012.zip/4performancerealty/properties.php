<?php require_once('/home/users/web/b2275/d5.remaxove/etc/conn_4pr.php'); ?>
<?php include("assets/meta.shtml"); ?>
<title>Performance Realty</title>
<?php include("assets/header.shtml"); ?>
  <!-- TOP MENU -->
  <div id="menuTop">
    <?php include("assets/menu.shtml"); ?>
  </div>
  <div id="content">
    <div id="mainContent3">
      <div class="container">
        <!-- DO NOT EDIT ABOVE HERE -->
        <!-- START CONTENT -->
        <h2>For Sale</h2>
        
        <!-- END CONTENT -->
        <!-- DO NOT EDIT BELOW HERE -->
        <iframe src="http://framing.usamls.net/framing/default.asp?f_id=R%5DVWRWWRWV%5DR" background="inherit" frameborder="0" height="700" width="855"></iframe> 															                                   
            

      </div>
    </div>
  </div>
  <?php include ("assets/footer.shtml"); ?>
